package com.assessment2.app;

public class PermanentEmployee extends Employee {
    // Attribute
    private double basicPay;

    // Constructor
    public PermanentEmployee(int employeeId, String employeeName, double basicPay) {
        super(employeeId, employeeName); // Call the superclass constructor
        this.basicPay = basicPay;
    }

    // Getter and Setter for basicPay
    public double getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(double basicPay) {
        this.basicPay = basicPay;
    }

    // Implement the calculateSalary method
    public void calculateSalary() {
        double pfAmount = basicPay * 0.12; // Calculate PF amount
        double computedSalary = basicPay - pfAmount; // Compute salary
        setSalary(computedSalary); // Set the computed salary using base class's method
    }
}

